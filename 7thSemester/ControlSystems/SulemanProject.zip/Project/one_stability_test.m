% Stability Test of a State-Space System
clc; clear; close all;

% Define State-Space Matrices
A = [17 2 3;
    3 -26 4;
    1 1 3]
B = [4;
    2;
    3]
C = [33 25 0.5];
D = [0];


% Display State-Space Matrices
disp('State-Space Matrices:');
disp('Matrix A:'); disp(A);
disp('Matrix B:'); disp(B);
disp('Matrix C:'); disp(C);
disp('Matrix D:'); disp(D);
disp('---------------------------------------------------------------');

% Eigenvalues of Matrix A
eigenvalues_A = eig(A);
disp('Eigenvalues of Matrix A (System Stability Check):');
disp(eigenvalues_A);
disp('---------------------------------------------------------------');

% Transfer Function Poles
[num, den] = ss2tf(A, B, C, D); % Convert to transfer function
poles_tf = roots(den);          % Compute poles of the transfer function
disp('Poles of the Transfer Function:');
disp(poles_tf);
disp('---------------------------------------------------------------');

% Create State-Space System
sys = ss(A, B, C, D);

% Plot Pole-Zero Map
figure(1);
pzmap(sys);
title('Pole-Zero Map');


% Plot Root Locus
figure(2);
rlocus(sys);
title('Root Locus');


% Plot Step Response
figure(3);
step(sys);
title('Step Response');
grid on;

% Detailed Explanation of Stability
disp('System Stability Analysis:');
if all(real(eigenvalues_A) < 0)
    disp(['The system is stable because ' ...
        'all eigenvalues of A have negative real parts.']);
else
    disp(['The system is unstable because ' ...
        'at least one eigenvalue of A has a non-negative real part.']);
end
disp('---------------------------------------------------------------');
%%
% Save all variables in the current workspace to a .mat file
save('stability.mat');
disp('All workspace data has been saved to all_data.mat');