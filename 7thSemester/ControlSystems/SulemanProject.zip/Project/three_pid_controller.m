%% PID Controller
clc; clear; close all;
load("controller_design.mat");
disp('All variables have been loaded from all_data.mat');
disp('---------------------------------------------------------------');
%%
A = [17 2 3;
    3 -26 4;
    1 1 3]
B = [4;
    2;
    3]
C = [33 25 0.5];
D = [0];

%figure(1);
%plot(out.ScopeData.time, out.ScopeData.signals.values)
%xlabel('Time (s)');
%ylabel('Response');
%title('Observer-based Feedback System Response');

sys2 = feedback(sys,1);
step(sys2)
info = stepinfo(sys2);
disp(info);
hold on
steady_state_value = info.SettlingMin;  % Approximate steady-state value
reference_value = 1;  % For step input, reference is 1
sse = abs(reference_value - steady_state_value);
disp(['Steady-State Error (Step Input): ', num2str(sse)]);

%%
sys2 = ss(A, B, C, D);
sys2 = feedback(sys2,1);
figure(2);
step(sys2)
figure(3);
info = stepinfo(sys2);
disp(info);
hold on
steady_state_value = info.SettlingMin;  % Approximate steady-state value
reference_value = 1;  % For step input, reference is 1
sse = abs(reference_value - steady_state_value);
disp(['Steady-State Error (Step Input): ', num2str(sse)]);
disp('---------------------------------------------------------------')

%% 
p = pidtune(sys2, 'pid');
sys_new = feedback(p*sys2,1);
step(sys_new)
info1 = stepinfo(sys_new);
disp(info1);
steady_state_value = info1.SettlingMin;  % Approximate steady-state value
reference_value = 1;  % For step input, reference is 1
sse = abs(reference_value - steady_state_value);
disp(['Steady-State Error (Step Input): ', num2str(sse)]);
disp('---------------------------------------------------------------')

%% 
% Ramp and parabolic response
figure(4);
t = 0:0.01:2000;  % Simulation time (adjust as needed)
ramp_input = t;
[response_ramp, t_ramp] = lsim(sys_new, ramp_input, t);
subplot(2,1,1);
plot(t_ramp, response_ramp, 'b', 'LineWidth', 1.5);
hold on;
plot(t_ramp, ramp_input, 'r--', 'LineWidth', 1); % Reference ramp
title('Ramp Response'); xlabel('Time (s)'); ylabel('Output');
legend('System Response', 'Ramp Input');
grid on;
% Parabolic Input
parabolic_input = 0.5 * t.^2;
[response_parabolic, t_parabolic] = lsim(sys_new, parabolic_input, t);
subplot(2,1,2);
plot(t_parabolic, response_parabolic, 'g', 'LineWidth', 1.5);
hold on;
plot(t_parabolic, parabolic_input, 'r--', 'LineWidth', 1); % Reference parabolic
title('Parabolic Response');
xlabel('Time (s)');
ylabel('Output');
legend('System Response', 'Parabolic Input');
grid on;
% Analyzing the steady-state errors for ramp and parabolic inputs
steady_state_error_ramp = abs(ramp_input(end) - response_ramp(end));
disp(['Steady-State Error for Ramp Input: ', num2str(steady_state_error_ramp)]);
steady_state_error_parabolic = abs(parabolic_input(end) - response_parabolic(end));
disp(['Steady-State Error for Parabolic Input: ', num2str(steady_state_error_parabolic)]);
