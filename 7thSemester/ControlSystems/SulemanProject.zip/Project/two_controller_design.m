clc; clear; close all;

% Load Required Data
load("stability.mat");
disp('All variables have been loaded from stability.mat');
disp('---------------------------------------------------------------');

% Initial Comment
disp("Since the C matrix is non-identity, we proceed with an observer-based feedback controller.");
disp('---------------------------------------------------------------');

% Controllability Analysis
P = ctrb(A, B);           % Compute Controllability Matrix
rank_P = rank(P);         % Compute Rank of Controllability Matrix
disp('Controllability Matrix (P):');
disp(P);
disp('Rank of Controllability Matrix (P):');
disp(rank_P);
if rank_P == size(A, 1)
    disp('The system is controllable.');
else
    disp('The system is not controllable.');
    error('Controller design cannot proceed without controllability.');
end
disp('---------------------------------------------------------------');

% Observability Analysis
Q = obsv(A, C);           % Compute Observability Matrix
rank_Q = rank(Q);         % Compute Rank of Observability Matrix
disp('Observability Matrix (Q):');
disp(Q);
disp('Rank of Observability Matrix (Q):');
disp(rank_Q);
if rank_Q == size(A, 1)
    disp('The system is observable.');
else
    disp('The system is not observable.');
    error('Observer design cannot proceed without observability.');
end
disp('---------------------------------------------------------------');

% Desired Poles for Controller and Observer
f = 1; g = 9; % Scaling factors for pole placement
h=8;
controller_poles = [-f * 2, -g * 2, -h*2];       % Controller poles
observer_poles = [-f * 10, -g * 10, -h*10];       % Observer poles
disp('Desired Controller Poles:');
disp(controller_poles);
disp('Desired Observer Poles:');
disp(observer_poles);
disp('---------------------------------------------------------------');

% State Feedback Gain Calculation
K = place(A, B, controller_poles);         % Compute State Feedback Gain Matrix
disp('State Feedback Gain Matrix (K):');
disp(K);
disp('---------------------------------------------------------------');

% Observer Gain Calculation
L = place(A', C', observer_poles)';        % Compute Observer Gain Matrix
disp('Observer Gain Matrix (L):');
disp(L);
disp('---------------------------------------------------------------');

% Closed-Loop System Matrices
A_cl = [(A - B * K), (B * K); zeros(size(A)), (A - L * C)];
B_cl = [B; zeros(size(B))];
C_cl = [C, zeros(size(C))];
D_cl = D;

% Define Closed-Loop State-Space System
sys_cl = ss(A_cl, B_cl, C_cl, D_cl);

% Step Response of Closed-Loop System
t = 0:0.01:10; % Time vector
[y, t] = step(sys_cl, t);

% Plot Step Response
figure;
plot(t, y);
xlabel('Time (s)');
ylabel('Response');
title('observer-based System Step Response');
grid on;

% Detailed Analysis
disp('Closed-Loop System Analysis:');
disp('The closed-loop system is constructed using observer-based state feedback.');
disp('---------------------------------------------------------------');

% Save Workspace Data
save('controller_design.mat');
disp('All workspace data has been saved to controller_design.mat');
