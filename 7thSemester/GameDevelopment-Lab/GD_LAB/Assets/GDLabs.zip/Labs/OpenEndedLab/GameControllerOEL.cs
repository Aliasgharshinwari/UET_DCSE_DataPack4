using UnityEngine;
using UnityEngine.SceneManagement; // For restarting the game

public class GameControllerOEL : MonoBehaviour
{
    public static GameControllerOEL Instance { get; private set; } // Singleton instance

    public GameObject gameOverUI; // Assign a UI panel for Game Over

    private void Awake()
    {
        // Singleton pattern - Ensure only one instance exists
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }


    public void GameOver()
    {
        Debug.Log("Game Over!");
        
        if (gameOverUI != null)
            gameOverUI.SetActive(true); // Show Game Over UI
        //Time.timeScale = 0;

        // Restart game after a delay
        //Invoke(nameof(RestartGame), 3f);
    }

    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
